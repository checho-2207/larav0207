<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CambioRepuestoController extends Controller
{
    //
}
